/*
 * Grad_Proj.c
 *
 * Created: 1/10/2021 12:14:42 AM
 * Author : Mohamed Olwan
 */ 

#include "bit_math.h"
#include "std_types.h"
#include "Proj_interface.h"
#include "MDIO_interface.h"


int main(void)
{
  /*SEtting SCK input and rest outputs*/
	mdio_pinStatus(PORTB,PIN4,OUTPUT);
	mdio_pinStatus(PORTB,PIN5,OUTPUT);
	mdio_pinStatus(PORTB,PIN7,OUTPUT);
	mdio_pinStatus(PORTB,PIN6,INPUT_FLOAT);
	/*Initialize UART and SPI communication protocols*/
	UART_Init(MUART_9600_Baud);
	SPI_InitM();
	
	
	
	
	while(1)
	{ 
		/*Receive serial data sent from Virtual Terminal*/
	u8_t var = USART_Receive();
	
	  /*Send data received from UART using SPI to other MCU*/
	SPI_send(var);

	}
}

