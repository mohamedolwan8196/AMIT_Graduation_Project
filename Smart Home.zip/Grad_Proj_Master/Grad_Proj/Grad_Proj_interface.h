/*
 * Grad_Proj_interface.h
 *
 * Created: 1/10/2021 12:42:07 AM
 *  Author: midoe
 */ 


#ifndef GRAD_PROJ_INTERFACE_H_
#define GRAD_PROJ_INTERFACE_H_





#endif /* GRAD_PROJ_INTERFACE_H_ */