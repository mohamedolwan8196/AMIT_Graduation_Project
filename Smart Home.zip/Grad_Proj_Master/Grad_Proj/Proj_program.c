 /*
 * Proj_program.c
 *
 * Created: 1/10/2021 8:08:19 PM
 *  Author: Mohamed Olwan
 */ 
#include "bit_math.h"
#include "std_types.h"
#include "Proj_interface.h"
#define  F_CPU   16000000UL
#include "util/delay.h"
/************************************************************************/
/*                 Method Implementation                                */
/************************************************************************/

void UART_Init(u16_t baud)
{
	/*Configure Baud rate*/
	MUART_UBRRH = (u16_t)(baud>>8);
	MUART_UBRRL = (u16_t)baud;
	/*Enable Transmit and Receive*/ 
	SET_BIT(MUART_UCSRB, 4);
	SET_BIT(MUART_UCSRB, 3);
	/*Choosing 2 stop bits & enable reading from UCSRC*/
	SET_BIT(MUART_UCSRC,7);
	SET_BIT(MUART_UCSRC,3);
	
	/*Choosing Asynchronous Process*/
	CLEAR_BIT(MUART_UCSRC,6);
	/*This part has the data bit config, 8bits  */
	CLEAR_BIT(MUART_UCSRB,2);
	SET_BIT(MUART_UCSRC,1);
	SET_BIT(MUART_UCSRC,2);
	
}

u8_t USART_Receive(void)
{
	while ( !(GET_BIT(MUART_UCSRA,7)));
	return MUART_UDR;
}

void SPI_InitM()
{	/*Slave mode select*/
	SET_BIT(MSPI_SPCR,4);
	/*Setting data mode*/
	SET_BIT(MSPI_SPCR,2);
	CLEAR_BIT(MSPI_SPCR,3);
	/*Enable SPI*/
	SET_BIT(MSPI_SPCR,6);
	/*Setting clock prescaler to freq/4*/
	CLEAR_BIT(MSPI_SPCR,0);
	CLEAR_BIT(MSPI_SPCR,1);
	
}
void SPI_InitS()
{
	/*Slave mode select*/
	CLEAR_BIT(MSPI_SPCR,4);
	/*Setting data mode*/
	SET_BIT(MSPI_SPCR,2);
	CLEAR_BIT(MSPI_SPCR,3);
	/*Enable SPI*/
	SET_BIT(MSPI_SPCR,6);
	/*Setting clock prescaler to freq/4*/
	CLEAR_BIT(MSPI_SPCR,0);
	CLEAR_BIT(MSPI_SPCR,1);
	
}



	
u8_t SPI_Recieve()
{
	/*Enable SPI*/
	SET_BIT(MSPI_SPCR,6);
	u16_t timeout = 0;
	/*Check if flag is set to 1 meaning serial data sent*/
	while( (GET_BIT(MSPI_SPSR, 7) == 0) && timeout < 10000)
	{
		timeout++;
		_delay_us(1);
		
	}
	/*reset SPI enable*/
	CLEAR_BIT(MSPI_SPCR, 6);
	
	return MSPI_SPDR;

}

void UART_send(u8_t data)
{
	/*Reset timeout variable*/
	 u8_t timeout_var = 0;
	
	/*Checking if UDR register is empty or not*/
	if(GET_BIT(MUART_UCSRA, 5))
	{
		/*Transmitting data over Tx pin*/
		MUART_UDR = data;
		
		/*Make sure that the data has been transmitted or timeout happens*/
		while((GET_BIT(MUART_UCSRA, 6) == 0) && timeout_var < 10000)
		{
			/*Increase timeout variable*/
			timeout_var++;
			
			/*Delay for 1ms*/
			_delay_ms(1);
		}
		
		/*Clearing Tx flag*/
		SET_BIT(MUART_UCSRA, 6);
	}
	else
	{
		/*Report error*/
	}
	
	/*Return from this function*/
	return;
}

void SPI_send(u8_t data)
{
	/*Set SPI enable to high*/
	SET_BIT(MSPI_SPCR,6);
	/*Timeout to avoid infinite loop*/
	u16_t timeout = 0;
	/*Set data to be send*/
	MSPI_SPDR = data;
	/*Loop on flag till data is sent*/
	
	while( (GET_BIT(MSPI_SPSR, 7) == 0) && timeout < 10000)
	{
		timeout++;
		_delay_us(1);
		
	}
	/*reset SPI enable to 0*/
	CLEAR_BIT(MSPI_SPCR,6);
}