/*
 * Proj_interface.h
 *
 * Created: 1/10/2021 8:08:44 PM
 *  Author: Mohamed Olwan
 */ 


#ifndef PROJ_INTERFACE_H_
#define PROJ_INTERFACE_H_
     /************************************************************************/
     /*            Private Macros                                            */
     /************************************************************************/
#define MUART_UBRRL   (*(volatile u8_t*)(0x29))
#define MUART_UCSRB   (*(volatile u8_t*)(0x2A))
#define MUART_UCSRA   (*(volatile u8_t*)(0x2B))
#define MUART_UDR     (*(volatile u8_t*)(0x2C))
#define MUART_UBRRH   (*(volatile u8_t*)(0x40))
#define MUART_UCSRC   (*(volatile u8_t*)(0x40))
#define MSPI_SPCR   (*(volatile u8_t*)(0x2D))
#define MSPI_SPSR   (*(volatile u8_t*)(0x2E))
#define MSPI_SPDR   (*(volatile u8_t*)(0x2F))

/************************************************************************/
/*                   Interfacing Macros                                 */
/************************************************************************/
#define MUART_2400_Baud 416
#define MUART_4800_Baud 207
#define MUART_9600_Baud 103
#define MUART_14400_Baud 68
/************************************************************************/
/*                    Method Prototypes                                 */
/************************************************************************/
/*UART initialize */
void UART_Init(u16_t baud);
/*UART receive data*/
u8_t USART_Receive(void);
/*UART send data*/
void UART_send(u8_t data);
/*Master Initialize SPI*/
void SPI_InitM();
/*SPI send data*/
void SPI_send(u8_t data);
/*Slave Recieve data*/
u8_t SPI_Recieve();
/*Initialize Slave SPI*/
void SPI_InitS();



#endif /* PROJ_INTERFACE_H_ */