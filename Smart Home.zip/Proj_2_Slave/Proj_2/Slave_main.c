/*
 * Grad_Proj.c
 *
 * Created: 1/10/2021 12:14:42 AM
 * Author : midoe
 */ 

#include "bit_math.h"
#include "std_types.h"
#include "Proj_interface.h"
#include "MDIO_interface.h"


int main(void)
{
	mdio_pinStatus(PORTA,PIN1,OUTPUT);
	mdio_pinStatus(PORTA,PIN2,OUTPUT);
	SPI_InitS();
	while(1)
	{
		u8_t slave=SPI_Recieve();
		
		if(slave=='a')
		{
			mdio_setPinValue(PORTA,PIN1,HIGH);
		}
		else if (slave=='b')
		{
			mdio_setPinValue(PORTA,PIN2,HIGH);
		}
	else
	{
		mdio_setPinValue(PORTA,PIN1,LOW);
		mdio_setPinValue(PORTA,PIN2,LOW);
	}
		
}
	
}


