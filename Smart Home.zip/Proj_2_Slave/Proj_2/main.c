/*
 * Grad_Proj.c
 *
 * Created: 1/10/2021 12:14:42 AM
 * Author : Mohamed Olwan
 */ 

#include "bit_math.h"
#include "std_types.h"
#include "Proj_interface.h"
#include "MDIO_interface.h"


int main(void)
{
	/*Setting pin 1 and 2 as LED output pins*/
	mdio_pinStatus(PORTA,PIN1,OUTPUT);
	mdio_pinStatus(PORTA,PIN2,OUTPUT);
	/*Setting SCK as output and rest of spi pins as input */
	mdio_pinStatus(PORTB,PIN4,INPUT_FLOAT);
	mdio_pinStatus(PORTB,PIN5,INPUT_FLOAT);
	mdio_pinStatus(PORTB,PIN7,INPUT_FLOAT);
	mdio_pinStatus(PORTB,PIN6,OUTPUT);
	
	/*Initialize Slave SPI by enabling spi and slave pin*/
	SPI_InitS();
	
	while(1)
	{
		/*Receive SPI data from master*/
		u8_t slave=SPI_Recieve();
		/*The data sent is either 'a' or 'b' */
		if(slave=='b')
		{
			/*case data is 'b' enable LED1*/
			mdio_setPinValue(PORTA,PIN1,HIGH);
			
		}
		else if (slave=='a')
		{
			/*Case data is 'a' enable LED2*/
			mdio_setPinValue(PORTA,PIN2,HIGH);
		}
	else
	{ 
		/*In case non is sent then switch both leds off*/
		mdio_setPinValue(PORTA,PIN1,LOW);
		mdio_setPinValue(PORTA,PIN2,LOW);
	}
		
}
}
	